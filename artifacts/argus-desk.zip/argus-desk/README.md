# Argus

Multi-document research desk. Ask, Brief, Compare, Conflicts, Timeline, and Chat. Every claim keeps a citation back to the passage.

## Open in VS Code

```bash
cd argus-desk
npm install
cp .env.example .env.local
npm run dev
```

Then open http://127.0.0.1:8080

Node 22 or newer. `npm install` needs the lockfile in this folder.

## Grok

Set `XAI_API_KEY` in `.env.local` if you want the planner and scribe to call Grok. The key stays on the server (`src/lib/rag/grok.functions.ts`). If the key is missing, or credits are exhausted, Chat and the other modes fall back to the local reader. That reader still quotes the sources.

## Where the app lives

| Path | What it is |
| --- | --- |
| `src/routes/index.tsx` | The only page. Renders the desk. |
| `src/components/argus/desk.tsx` | Library, thread, evidence, modes, composer. |
| `src/components/argus/markdown.tsx` | Cited markdown. |
| `src/lib/rag/types.ts` | Modes, documents, citations, analysis. |
| `src/lib/rag/store.ts` | Zustand desk. Documents and chat stay in localStorage. |
| `src/lib/rag/run.ts` | Planner, retriever, critic, scribe. |
| `src/lib/rag/local.ts` | Local reader, conflicts, follow-ups. |
| `src/lib/rag/grok.functions.ts` | Server functions for Grok. |
| `src/lib/rag/sample.ts` | Northline harbor dossier. |
| `src/lib/rag/parse.ts` | PDF, Word, and text upload. |
| `src/lib/rag/corpus.ts` | Chunking and BM25. |

Upload or paste your own files from the library, or load the Northline dossier. Documents never leave the browser except the short passages sent to Grok when a key is set.
